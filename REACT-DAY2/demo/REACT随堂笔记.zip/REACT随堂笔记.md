##REACT随堂笔记
@(日常记录)

react是facebook公司开发的一款js框架
- v16.xx
- 一款mvc框架（model view controller），react基本上需要用户来操作的只有view层（react独带自己的一个语法：jsx）
- 渐进式框架
- 提供的jsx语法不能直接被浏览器渲染和解析，需要基于babel进行转义（真实项目中使用react，很少被直接使用，而是基于 es6+webpack(babel...)+react+react-dom+react-router+react-redux+axios...）
- ...

> 渐进式框架：
> react的核心模块只有 react / react-dom，其中react是核心，react-dom是用来渲染真实DOM的；
> 真实项目中，我们根据业务需求可能需要其余的react操作部分，我们再单独安装即可：react-router、react-redux...
> 
> 优势：体积小，用到什么再安装什么

###react的脚手架
> vue-cli 是vue框架常用的脚手架
>  
> create-react-app是react官方提供的脚手架，应用最多；generator-z-react-cli这个react脚手架也是比较受欢迎的；

1、在全局环境中安装 create-react-app 包
> $ npm install -g create-react-app

2、使用脚手架初始化一个项目
> $ create-react-app  my-project

基于react脚手架安装的应用，配置了如下的模块
- react 、react-dom，其余的模块需要自己额外的安装
- 会自己生成一套webpack的配置项（当前脚手架为了保证项目结构的简介美观，把webpack相关配置项文件隐藏到node_modules文件夹中了，这样也引发了一个问题：`如果我们需要修改配置项信息[例如:我使用了less,我需要自己安装配置一个less-loader来编译less],不能去修改创建的webpack`）
- ...

3、开始使用
> 安装完成后，提供了一些命令供我们操作
> \$ yarn start ：启动开发环境的服务，开发的时候执行它即可
> \$ yarn build：把项目基于webpack进行打包部署，开发完成，产品上线的时候执行一次，把生成的静态文件部署到服务器上即可
> \$ yarn eject：把隐藏的webpack配置项暴露到项目中，这样我们就可以自己修改配置信息了（这个操作是不可逆的，一但执行，无法在把配置信息隐藏回去）
> ...

4、基于eject重新配置webpack信息
> \$ yarn eject

配置less处理
- 开发环境下需要处理
- 生产环境下也需要处理

> \$ yarn add less-loader    安装less的加载器

webpack.config.dev.js / webpack.config.prod.js
![Alt text](./1520390531037.png)

----

###JSX元素（虚拟DOM元素）到 HTML元素（真实DOM元素）解析的原理

1、基于babel（preset-react语法模块）把jsx语法变为ES6语法
http://babeljs.io/repl/

> babel转义的时候，遇到一个单独的HTML标签，都会把其单独的转义为 React.createElement() 这种模式：每一个标签都有一个自己对应的createElement
>  
> React.createElement([tagName],[props元素标签属性集合],...) 后面的参数取决于是否有子内容或者子元素，有的话，参数个数就是儿子的个数

2、基于React.createElement创建出JSX元素对应的元素对象
> React是一个类，createElement是当前类的静态私有属性（和类的实例没关系）
>  
> createElement执行会根据传递的信息，创建出一个个对象
> - type：标签名
> - key：我们设置的唯一key值
> - ref：与后面讲的非受控组件有关系
> - props：是当前jsx元素的属性集合
>   + 凡是在JSX元素上设置的属性（除了key和ref之外，其余大部分都赋值给了props）
>   + children：如果当前JSX有子元素，会给props多设置一个children的属性，存放子元素的相关信息（没有子节点则没有这个属性）
>   + childern的值也是不固定的，如果子节点是个文本，它的值也是一个文本；如果子节点是个元素，则继续调用createElement转换成一个其它元素的对象，它的值就是这个对象；有多个子节点，存储的值是一个数组
>   + ...
> - ...

3、基于ReactDOM.render把JSX元素创建出来的对象，递归遍历，最后动态增加到页面中，转换为真实的DOM元素