##REACT组件之间的信息传递
复合组件：REACT组件进行嵌套（通俗理解：父组件套子组件...）

###父子组件之间的信息传递
父子组件之间的信息传递是单向的（只能父组件把信息传递给子组件），通过属性进行传递
```javascript
class Panel extends React.Component {
    render() {
        let {title, con} = this.props;//=>父组件接收到的信息（或者是父组件本身的状态信息）
        return <div className="panel panel-default">
            <Header title={title}></Header>
            {/*在调取子组件HEADER的时候，把一些需要传递的信息。传递给子组件的属性props*/}
        </div>;
    }
}

class Header extends React.Component {
    render() {
        let {title} = this.props;//=>子组件通过获取属性值接收到父组件专递的内容（接下来就可以使用了）
        return <header className="panel-heading">
            <h2 className="panel-title">
				{title}
            </h2>
        </header>;
    }
}
```
真实项目中，除了父组件需要把信息传递给子组件，很多时候，子组件也想把一些信息反馈给父组件，这样我们应该如何的进行处理？
> 利用JS中的回调函数机制可以完成这个操作（原理类似于JSONP）
> 1、父组件把自己的一个方法通过属性传递给子组件（子组件中就可以获取父组件的这个方法了）
> 2、在子组件中把父组件传递的方法执行，把子组件中的一些信息传递给父组件，基于这套回调机制，完成了子组件传递信息给父组件
```javascript
class Panel extends React.Component {
    constructor() {
        super();
        this.state = {num: 0};//=>父组件本身的状态信息，用来管理计数器结果的
    }
	//=>以后执行fn方法，传递一个最新的计数结果，我们修改父组件的状态信息，导致父组件重新渲染，看到最新的结果
    fn = n => {
        this.setState({
            num: n
        });
    };

    render() {
        return <div className="panel panel-default">
	        {/*在调取子组件的时候，通过回调函数机制，把父组件中的fn方法传递给子组件（通过属性传递）*/}
            <Header callback={this.fn}/>
            <p>计数器的结果是：{this.state.num}</p>
        </div>;
    }
}

class Header extends React.Component {
    componentDidMount() {
        //=>子组件第一次渲染完成后，获取父组件传递的属性信息 callback，存储的值就是父组件中的fn这个方法，此时我们设置定时器，把传递的fn执行，并且传递不同的计数结果
        let {callback} = this.props;
        let n = 0;
        setInterval(() => {
            n++;
            callback(n);
        }, 1000);
    }

    ...
}
```
更复杂的信息传递（例如：爷爷组件想把一些信息传递给孙子组件），依然是基于属性进行传递，具体操作：爷爷组件先通过属性把信息传递给父组件，父组件把接收的信息在传递给孙子组件（也是通过属性传递），依次类推，一层层的进行传递即可...

###平行组件之间的信息传递
所谓平行组件，不像父子组件一样存在嵌套关系，两个组件是独立的，没有必然的联系，此时就不能像父子组件一样，基于属性进行信息传递了，那么平行组件之间想要实现信息传递，该如何处理呢？

**第一种方案：让平行组件拥有共同的父级组件**
> 例如有A/B两个平行组件，我们创建一个共同的父组件P，A想把信息传递给B，我们按照如下步骤完成：
> 1、A先把信息传递给P（基于父子组件之间回调函数传递信息机制）
> 2、P在把A传递的信息，传递给B即可
```javascript
class P extends React.Component {
    constructor() {
        super();
        this.state = {msg: '珠峰'};
    }

	//=>4、当子组件A把这个方法执行（把信息传递给形参MSG了），我们修改父组件P的状态信息，父组件重新渲染JSX元素
    fn = msg => this.setState({msg});

    render() {
        return <div>
            {/*1、父组件P把自己的FN方法，通过属性传递给A组件*/}
            <A callback={this.fn}/>
            
            {/*
              * 2、父组件P把自己的状态信息MSG，通过属性传递给B组件
              * 5、当组件重新渲染的时候，会把最新的MSG状态信息传递给子组件B（依然是基于属性传递）
              */}
            <B msg={this.state.msg}/>
        </div>;
    }
}

class A extends React.Component {
    componentDidMount() {
        //=>3、2000MS后，在A组件中把一条最新值“hello world”，通过执行传递进来的回调函数，传递给父组件P的FN这个方法
        setTimeout(() => {
            let {callback} = this.props;
            callback && callback('hello world');
        }, 2000);
    }

    render() {
        return <div>我是A</div>;
    }
}

class B extends React.Component {
    render() {
        //=>每一次传递的属性发生改变，当前B组件也要重新的进行传染（涉及的钩子函数：shouldComponentUpdate和componentWillReceiveProps）
        return <div>
            {this.props.msg}
        </div>;
    }
}
```
这种方案有自己的一些弊端：
1、嵌套一个父组件，信息传递的步骤过于繁琐
2、项目中很多时候，两个平行组件之间，我们很难找到共同的父组件
...

**第二种方案：基于本地存储和发布订阅设计模式完成**
> => 创建一个容器（store），调取A/B组件的时候，把容器通过属性传递给每一个组件
> 
> => A组件中，我们在指定条件下，把需要传递给B组件的信息存储到本地（基于localStorage/cookie），同时通知STORE容器中存储的方法依次执行
>  
> => B组件中，把一个后续需要执行的方法放到STORE中，而这个方法的目的：获取本地最新存储的信息，通过修改组件的状态，完成信息的重新渲染

`index.js`
```javascript
let store = [];//=>创建容器
ReactDOM.render(<div>
    {/*调取组件的时候把容器通过属性传递给组件，A/B传递的store是相同的一个容器*/}
    <A store={store}/>
    <B store={store}/>
</div>, window.root);
```

`component/A.js`
```javascript
export default class A extends React.Component {
    componentDidMount() {
        let {store} = this.props;
        localStorage.removeItem('pubMsg');
        setTimeout(() => {
            //=>2000MS后，把本地存储的信息进行修改，然后通知容器中存储的方法依次执行
            localStorage.setItem('pubMsg', 'HELLO');
            store.forEach(item => item());
        }, 2000);
    }

    render() {
        return <div>
            我是A
        </div>;
    }
}
```

`component/B.js`
```javascript
export default class B extends React.Component {
    constructor() {
        super();
        this.state = {msg: ''};
    }

    componentDidMount() {
        let {store} = this.props;
        //=>向容器中订阅一个方法，方法的目的：获取本地最新的pubMsg，赋值给组件的STATE状态；后期在A组件中可以把订阅的方法执行
        store.push(() => {
            this.setState({msg: localStorage.getItem('pubMsg')});
        });
    }

    render() {
        return <div>
            我是B
            <span style={{color: 'red'}}>{this.state.msg}</span>
        </div>;
    }
}
```

除了以上两种方案，目前项目中比较常用的还有 **redux/react-redux**，基于这两个模块，可以快速高效的进行状态统一管理，实现平行组件（或者父子组件）之间的信息通信

在后续的文章中，将会为大家分享redux核心原理，以及解读redux中的源码；想要具体详细了解，可以观看我们录制的精彩视频（扫码观看）
![Alt text](./1520745162049.png)
